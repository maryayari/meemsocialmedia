# Connecty---A-Social-Media-App
This is the api of the social media app using django rest framework

Task baki--->django channel use garera chat system banauny..
