from django.apps import AppConfig


class VotesConfig(AppConfig):
    name = 'votes'
